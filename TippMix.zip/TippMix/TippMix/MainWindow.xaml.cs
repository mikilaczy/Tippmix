﻿using System;
using System.IO;
using System.Linq;
using System.Windows;

namespace TippMix
{
    public partial class MainWindow : Window
    {
        private const string UsersFilePath = "users.txt";

        public MainWindow()
        {
            InitializeComponent();
        }

        private void Login_Click(object sender, RoutedEventArgs e)
        {
            string username = UsernameLogin.Text;
            string password = PasswordLogin.Password;

            if (IsValidUser(username, password))
            {
                MainContent mainContent = new MainContent();
                mainContent.Show();
                this.Close();
            }
            else
            {
                MessageBox.Show("Hibás felhasználónév vagy jelszó.");
            }
        }

        private void Register_Click(object sender, RoutedEventArgs e)
        {
            string username = UsernameRegister.Text;
            string password = PasswordRegister.Password;
            string confirmPassword = PasswordRegisterConfirm.Password;

            if (password != confirmPassword)
            {
                MessageBox.Show("A jelszavak nem egyeznek.");
                return;
            }

            if (RegisterUser(username, password))
            {
                MessageBox.Show("Sikeres regisztráció!");
            }
            else
            {
                MessageBox.Show("A felhasználónév már létezik.");
            }
        }

        private bool IsValidUser(string username, string password)
        {
            if (!File.Exists(UsersFilePath))
            {
                return false;
            }

            var lines = File.ReadAllLines(UsersFilePath);
            return lines.Any(line =>
            {
                var parts = line.Split(';');
                return parts.Length == 2 && parts[0] == username && parts[1] == password;
            });
        }

        private bool RegisterUser(string username, string password)
        {
            if (File.Exists(UsersFilePath))
            {
                var lines = File.ReadAllLines(UsersFilePath);
                if (lines.Any(line =>
                {
                    var parts = line.Split(';');
                    return parts.Length > 0 && parts[0] == username;
                }))
                {
                    return false;
                }
            }

            using (StreamWriter sw = File.AppendText(UsersFilePath))
            {
                sw.WriteLine($"{username};{password}");
            }

            return true;
        }
    }
}

