﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace TippMix
{
    /// <summary>
    /// Interaction logic for OfferDetail4.xaml
    /// </summary>
    public partial class OfferDetail4 : Window
    {
        public OfferDetail4()
        {
            InitializeComponent();
        }
        private void Order_Click(object sender, RoutedEventArgs e)
        {
            string email = EmailTextBox.Text;

            MessageBox.Show($"Megrendelés sikeres! Email: {email}");
        }
    }
}
