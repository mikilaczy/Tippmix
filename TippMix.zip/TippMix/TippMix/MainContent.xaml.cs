﻿using System.Windows;

namespace TippMix
{
    public partial class MainContent : Window
    {
        public MainContent()
        {
            InitializeComponent();
        }

        private void Offer_Click1(object sender, RoutedEventArgs e)
        {
            OfferDetail offerDetail = new OfferDetail();
            offerDetail.ShowDialog();
        }

        private void Offer_Click2(object sender, RoutedEventArgs e)
        {
            OfferDetail2 offerDetail2 = new OfferDetail2();
            offerDetail2.ShowDialog();
        }

        private void Offer_Click3(object sender, RoutedEventArgs e)
        {
            OfferDetail3 offerDetail3 = new OfferDetail3();
            offerDetail3.ShowDialog();
        }

        private void Offer_Click4(object sender, RoutedEventArgs e)
        {
            OfferDetail4 offerDetail4 = new OfferDetail4();
            offerDetail4.ShowDialog();
        }
    }
}
