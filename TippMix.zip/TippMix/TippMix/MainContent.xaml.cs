﻿using System.Windows;

namespace TippMix
{
    public partial class MainContent : Window
    {
        public MainContent()
        {
            InitializeComponent();
        }

        private void Offer_Click(object sender, RoutedEventArgs e)
        {
            OfferDetail offerDetail = new OfferDetail();
            offerDetail.ShowDialog();
        }
    }
}
