﻿using System.Windows;

namespace TippMix
{
    public partial class OfferDetail : Window
    {
        public OfferDetail()
        {
            InitializeComponent();
        }

        private void Order_Click(object sender, RoutedEventArgs e)
        {
            string email = EmailTextBox.Text;
           
            MessageBox.Show($"Megrendelés sikeres! Email: {email}");
        }
    }
}
